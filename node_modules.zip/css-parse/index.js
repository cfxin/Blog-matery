module.exports = require('css').parse;
