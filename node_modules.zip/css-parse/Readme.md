# css-parse

  JavaScript CSS parser for Node.js (exports the `parse` method of [css](https://github.com/reworkcss/css))

## Installation

  $ npm install css-parse

## Usage

  Please see the [css](https://github.com/reworkcss/css) module documentation.

## License

  MIT
